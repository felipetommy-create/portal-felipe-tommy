# Auto-envio sem Console

Instalação neste computador, uma única vez:

1. No Chrome, abra `chrome://extensions`.
2. Ative **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação**.
4. Selecione esta pasta, que contém `manifest.json`.
5. Recarregue o painel do portal.

No dia a dia: **Auto-envio → Abrir robô no WhatsApp → Iniciar**.
Deixe o WhatsApp Web conectado no mesmo perfil do Chrome. O botão leva os grupos
selecionados, a pausa e o intervalo variável configurados no painel. Carregar o
robô não envia mensagens; ele aguarda Iniciar. A janela de sincronização e o
controle de progresso continuam funcionando como antes.

Se já houver um robô aberto, feche-o pelo X antes de carregar outra seleção.
Se houver várias abas do WhatsApp na mesma janela, deixe somente a que quer usar.

Em outro computador: baixe o ZIP pelo painel, extraia para uma pasta permanente
e selecione essa pasta no passo 4. Não apague nem mova a pasta após instalar.

## Manutenção

O código do robô vem da função `ftWhatsAppRunner` no HTML do painel.
Execute `node 01-PAINEL/gerar-extensao-autoenvio.cjs` a partir da raiz do projeto
após mudar a versão do painel ou o robô. Depois atualize o ZIP de distribuição.
Não edite `runner.js` manualmente. O carregamento recusa versões diferentes.

Após atualizar os arquivos, clique no botão de recarregar da extensão em
`chrome://extensions` e recarregue a aba do painel.

A extensão só injeta seu robô empacotado no WhatsApp Web. A ponte recebe apenas
dados do endereço oficial do painel. Não usa código remoto, eval, acesso ao
clipboard, cookies, senhas ou chave do Supabase. As permissões são scripting e
acesso ao WhatsApp Web, com um script de conexão restrito ao painel do portal.

Documentação do Chrome:
https://developer.chrome.com/docs/extensions/reference/api/scripting
https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked
