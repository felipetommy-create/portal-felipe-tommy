'use strict';
importScripts('runner.js');
const PANEL_ORIGIN = 'https://felipetommy-create.github.io';
const PANEL_PATH = '/portal-felipe-tommy/';
let loading = false;

function trustedSender(sender) {
  try {
    const url = new URL(sender.url);
    return sender.id === chrome.runtime.id && sender.tab?.id != null && sender.frameId === 0 &&
      url.origin === PANEL_ORIGIN && [PANEL_PATH, PANEL_PATH + 'index.html'].includes(url.pathname);
  } catch { return false; }
}

function validatePayload(p) {
  if (!p || p.v !== 5 || p.autoSource !== true || p.versao !== FT_RUNNER_VERSION) throw Error('Atualize a extensão e recarregue o painel: as versões do robô são diferentes.');
  if (p.dryRun !== false || p.reviewOnly !== false || p.testBatch || p.channelName) throw Error('Use o carregamento normal do Auto-envio.');
  if (p.bridgeUrl !== PANEL_ORIGIN + PANEL_PATH + 'encaminhador-bridge.html') throw Error('Endereço de sincronização inválido.');
  if (!Array.isArray(p.groups) || p.groups.length < 1 || p.groups.length > 1000) throw Error('Seleção de grupos inválida.');
  const ids = new Set(), names = new Set();
  const groups = p.groups.map(g => {
    if (typeof g?.id !== 'string' || !/^[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}$/i.test(g.id) || typeof g.nome !== 'string' || !g.nome.trim() || g.nome.length > 500) throw Error('Grupo sem identificação válida.');
    const name = g.nome.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
    if (ids.has(g.id) || names.has(name)) throw Error('Há grupos repetidos na seleção.');
    ids.add(g.id); names.add(name);
    return {id: g.id, nome: g.nome};
  });
  if (!Array.isArray(p.keywords) || p.keywords.length > 100 || p.keywords.some(k => typeof k !== 'string' || k.length > 100)) throw Error('Palavras-chave inválidas.');
  if (!Number.isSafeInteger(p.delayMs) || p.delayMs < 2000 || p.delayMs > 3600000 || !Number.isSafeInteger(p.jitterMs) || p.jitterMs < 0 || p.jitterMs > 3600000) throw Error('Intervalos inválidos.');
  const project = new URL(p.sb?.url);
  if (project.protocol !== 'https:' || !/^[a-z0-9]+\.supabase\.co$/.test(project.hostname) || project.port || project.username || project.password || project.search || project.hash || project.pathname !== '/' || p.sb.slug !== 'auto-canal') throw Error('Projeto de sincronização inválido.');
  // Lista explícita: nenhum campo extra, chave ou código atravessa esta ponte.
  return {v: 5, autoSource: true, dryRun: false, reviewOnly: false, versao: FT_RUNNER_VERSION,
    bridgeUrl: p.bridgeUrl, articleTitle: '', articleLinks: [], groups, keywords: [...p.keywords],
    delayMs: p.delayMs, jitterMs: p.jitterMs, sb: {url: project.origin, slug: 'auto-canal'}};
}

function validateCleanup(p) {
  if (!p || p.v !== 1 || p.mode !== 'cleanup' || p.versao !== FT_RUNNER_VERSION) throw Error('Atualize a extensão e recarregue o painel.');
  if (!/^[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}$/i.test(p.jobId) || typeof p.dryRun !== 'boolean' || typeof p.keepStarred !== 'boolean') throw Error('Opções de limpeza inválidas.');
  if (!Array.isArray(p.groups) || !p.groups.length || p.groups.length > 1000) throw Error('Seleção de grupos inválida.');
  const ids = new Set(), names = new Set();
  const groups = p.groups.map(g => {
    if (typeof g?.id !== 'string' || !/^[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}$/i.test(g.id) || typeof g.nome !== 'string' || !g.nome.trim() || g.nome.length > 500) throw Error('Grupo inválido.');
    const name = g.nome.normalize('NFC').replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '').replace(/\s+/g, ' ').trim();
    if (ids.has(g.id) || names.has(name)) throw Error('Há grupos repetidos na seleção.');
    ids.add(g.id); names.add(name); return {id:g.id, nome:g.nome};
  });
  return {v:1, mode:'cleanup', versao:FT_RUNNER_VERSION, jobId:p.jobId, dryRun:p.dryRun, keepStarred:p.keepStarred, groups};
}

async function loadRunner(payload, sender, cleanup = false) {
  const p = cleanup ? validateCleanup(payload) : validatePayload(payload);
  const tabs = await chrome.tabs.query({url: 'https://web.whatsapp.com/*'});
  let tab;
  if (tabs.length === 1) tab = tabs[0];
  else if (tabs.length > 1) {
    const sameWindow = tabs.filter(t => t.windowId === sender.tab.windowId);
    if (sameWindow.length === 1) tab = sameWindow[0];
    else throw Error('Há mais de uma aba do WhatsApp. Deixe apenas a aba que você quer usar nesta janela e tente novamente.');
  } else {
    await chrome.tabs.create({url: 'https://web.whatsapp.com/'});
    throw Error('WhatsApp aberto. Aguarde carregar, entre na sua conta e clique novamente em Abrir robô no WhatsApp.');
  }
  if (tab.status !== 'complete') throw Error('Aguarde o WhatsApp terminar de carregar e tente novamente.');
  const results = await chrome.scripting.executeScript({target: {tabId: tab.id}, world: 'MAIN', func: cleanup ? ftExtensionCleanupLaunch : ftExtensionLaunch, args: [p]});
  const result = results[0]?.result;
  if (!result?.ok) throw Error(result?.error || 'Não foi possível abrir o robô. Recarregue o WhatsApp e tente novamente.');
  await chrome.tabs.update(tab.id, {active: true});
  await chrome.windows.update(tab.windowId, {focused: true});
  return {ok: true, count: p.groups.length, version: FT_RUNNER_VERSION};
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!trustedSender(sender)) { respond({ok: false, error: 'Origem não autorizada.'}); return false; }
  if (message?.action === 'ping') { respond({ok: true, version: FT_RUNNER_VERSION}); return false; }
  if (!['load', 'load-cleanup'].includes(message?.action)) { respond({ok: false, error: 'Operação inválida.'}); return false; }
  if (loading) { respond({ok: false, error: 'O robô já está sendo carregado. Aguarde.'}); return false; }
  loading = true;
  loadRunner(message.payload, sender, message.action === 'load-cleanup').then(respond, error => respond({ok: false, error: error.message})).finally(() => { loading = false; });
  return true;
});
