// Ponte restrita ao painel. Transmite dados; nunca recebe código para executar.
(() => {
  'use strict';
  const protocol = 'ft-auto-extension-v1';
  if (!['/portal-felipe-tommy/', '/portal-felipe-tommy/index.html'].includes(location.pathname)) return;
  window.addEventListener('message', async event => {
    const m = event.data;
    if (event.source !== window || event.origin !== location.origin || m?.protocol !== protocol || m.direction !== 'request') return;
    if (!['ping', 'load'].includes(m.action) || typeof m.id !== 'string' || m.id.length > 80) return;
    let response;
    try {
      response = await chrome.runtime.sendMessage({action: m.action, payload: m.payload});
    } catch {
      response = {ok: false, error: 'Recarregue esta aba depois de instalar ou atualizar a extensão.'};
    }
    window.postMessage({protocol, direction: 'response', id: m.id, ...response}, location.origin);
  });
})();
