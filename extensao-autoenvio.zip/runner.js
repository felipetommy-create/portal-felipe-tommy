// Gerado por gerar-extensao-autoenvio.cjs. Não editar manualmente.
const FT_RUNNER_VERSION="2.11.2";
function ftExtensionLaunch(P) {
  if (location.origin !== 'https://web.whatsapp.com') return {ok:false,error:'Abra o WhatsApp Web.'};
  if (window.__ftAuto || document.getElementById('_ftForward')) return {ok:false,error:'Já existe um robô aberto no WhatsApp. Feche-o pelo X antes de carregar outra seleção.'};
  function ftWhatsAppRunner(P){
  'use strict';
  if(location.hostname!=='web.whatsapp.com'){alert('Abra este código no WhatsApp Web.');return;}
  if(window.__ftAuto){alert('Feche o encaminhador anterior antes de abrir outro.');return;}
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  const {groups,keywords=[],sb,channelName='Portal Felipe Tommy',dryRun=false,reviewOnly=false,versao='?'}=P;
  if(P.testBatch&&(reviewOnly||dryRun||![5,10].includes(groups?.length))){alert('Teste real limitado a 5 ou 10 grupos. Gere novamente o código após selecionar os destinos.');return;}
  if(reviewOnly&&(groups?.length!==1||groups[0].id!=='ft-private-review'||groups[0].nome!=='Revisão para Publicação 📲')){alert('Ciclo privado inválido: só Revisão para Publicação 📲 é permitida.');return;}
  if(!Array.isArray(groups)||!groups.length||!sb?.slug||sb.slug==='sem-slug'){alert('Carregue a matéria e selecione os grupos no painel.');return;}
  const byName=new Map();
  for(const g of groups){
    const name=norm(g.nome);
    if(!g.id||!name||byName.has(name)){alert('Há grupos sem identificação ou com nomes iguais. Corrija a lista no painel.');return;}
    byName.set(name,g);
  }
  let key='ft_forward_v4:'+sb.url+':'+sb.slug+(reviewOnly?':review':'');
  const lockKey=P.autoSource?'ft_forward_channel:'+sb.url+':'+norm(channelName):key;
  let ledger;
  try{
    ledger=P.autoSource?{sent:{},pending:[],source:null}:JSON.parse(localStorage.getItem(key)||'null')||{sent:{},pending:[],source:null};
    if(!ledger.sent||!Array.isArray(ledger.pending))throw Error();
    if(!P.autoSource)localStorage.setItem(key,JSON.stringify(ledger));
  }catch{alert('Não foi possível abrir o controle desta matéria no navegador. Nenhum envio iniciado.');return;}
  const save=()=>localStorage.setItem(key,JSON.stringify(ledger));
  let state='idle',busy=false,closed=false,source=ledger.source;
  let remaining=new Map(byName),synced=new Set();
  const box=document.createElement('section');
  box.id='_ftForward';
  box.style.cssText='position:fixed;top:16px;right:16px;width:min(370px,94vw);background:#111b21;color:#e9edef;border:1px solid #40545e;border-radius:12px;padding:14px;font:13px Segoe UI,sans-serif;z-index:2147483647;box-shadow:0 8px 30px #0008';
  box.innerHTML='<div style="display:flex;justify-content:space-between"><b>Encaminhador FT · v'+versao+'</b><button data-act="close" aria-label="Fechar encaminhador">✕</button></div><p data-status aria-live="polite"></p><progress max="100" value="0" style="width:100%;accent-color:#00a884"></progress><div data-log style="max-height:160px;overflow:auto;font-size:12px;margin:10px 0"></div><div style="display:flex;gap:6px;flex-wrap:wrap"><button data-act="start">▶ Iniciar</button><button data-act="pause" disabled>⏸ Pausar</button><button data-act="stop" disabled>■ Parar</button><button data-act="report">↓ Relatório</button></div>';
  const buttonStyles=document.createElement('style');
  buttonStyles.textContent=`
    #_ftForward button[data-act]{background:var(--ft-button-bg,#9fd7ff)!important;color:#101820!important;border:2px solid transparent!important;border-radius:7px!important;padding:9px 12px!important;min-height:40px!important;font:700 13px/1.2 "Segoe UI",sans-serif!important;cursor:pointer!important;opacity:1!important;box-shadow:none!important;text-shadow:none!important}
    #_ftForward button[data-act="start"]{--ft-button-bg:#50dfb4}
    #_ftForward button[data-act="pause"]{--ft-button-bg:#ffda75}
    #_ftForward button[data-act="stop"]{--ft-button-bg:#ff929c}
    #_ftForward button[data-act="report"]{--ft-button-bg:#9fd7ff}
    #_ftForward button[data-act="close"]{--ft-button-bg:#dce6ef;min-width:40px!important}
    #_ftForward button[data-act]:disabled{background:#344957!important;color:#d9e4ec!important;border-color:#637c8d!important;cursor:not-allowed!important}
    #_ftForward button[data-act]:not(:disabled):hover{border-color:#fff!important}
    #_ftForward button[data-act]:focus-visible{outline:3px solid #fff!important;outline-offset:3px!important}
  `;
  box.appendChild(buttonStyles);
  document.body.appendChild(box);
  window.__ftAuto=true;
  const ui=s=>box.querySelector(s),status=t=>{ui('[data-status]').textContent=t;};
  const log=t=>{const line=document.createElement('div');line.textContent=new Date().toLocaleTimeString()+' '+t;ui('[data-log]').appendChild(line);ui('[data-log]').scrollTop=ui('[data-log]').scrollHeight;};
  const progress=()=>{ui('progress').value=100*(groups.length-remaining.size)/groups.length;};
  status(dryRun?'Teste sem envio: prepara dois lotes e cancela.':reviewOnly?'ENVIO REAL: somente Revisão para Publicação 📲; volta ao canal e encerra.':groups.length+' grupos selecionados. Pronto para iniciar.');
  const rawSleep=ms=>new Promise(r=>setTimeout(r,ms));
  const checkpoint=async()=>{
    while(state==='paused'&&!closed)await rawSleep(150);
    if(state==='stopped'||closed)throw Error('Interrompido. O progresso já confirmado foi preservado.');
  };
  const sleep=async ms=>{for(let left=ms;left>0;left-=150){await checkpoint();await rawSleep(Math.min(left,150));}await checkpoint();};
  const wait=async(fn,why,timeout=12000)=>{
    let elapsed=0;
    while(elapsed<timeout){await checkpoint();const value=fn();if(value)return value;await sleep(200);elapsed+=200;}
    throw Error(why);
  };
  const visible=e=>!!e?.isConnected&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
  const enabled=e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true';
  const all=(s,root=document)=>root?[...root.querySelectorAll(s)]:[];
  const labeled=(root,label)=>all('button,[role="button"]',root).find(e=>norm(e.getAttribute('aria-label'))===norm(label)&&enabled(e));
  const click=async e=>{await checkpoint();if(!enabled(e))throw Error('Controle ausente ou desabilitado.');e.click();};
  const main=()=>document.getElementById('main');
  const selectedBox=m=>m?all('input[type="checkbox"]',m).find(e=>/^caixa de selecao|^select (message|update)/.test(norm(e.getAttribute('aria-label')))):null;
  const checked=e=>!!e&&(e.checked===true||e.getAttribute('aria-checked')==='true');
  const messages=()=>all('[data-id][data-testid^="conv-msg-"]',main()||document);
  // WhatsApp 15/10/2026 usa IDs React (_r_...), sem "-option-".
  // Reconhecer a enquete pela estrutura, nunca pelo texto ou por checkbox genérico.
  const isPoll=el=>!!el?.querySelector('[data-testid="poll-bubble"],input[id*="-option-"]');
  const pollReady=el=>{
    const bubble=el?.querySelector('[data-testid="poll-bubble"]');
    if(bubble)return all('[data-testid^="poll-option-row-label-"]',bubble).length>=2;
    return !!el?.querySelector('input[id*="-option-"]');
  };
  const modal=()=>all('[role="dialog"]').find(d=>visible(d)&&all('h2,[role="heading"]',d).some(h=>norm(h.textContent)==='encaminhar atualizacoes para'));
  const rows=m=>all('[data-testid="checkbox-selectable-wrapper"][role="checkbox"]',m);
  const rowName=r=>{const t=r.querySelector('[data-testid="cell-frame-title"] [title]');return t?.getAttribute('title')||'';};
  const scrollParent=(e,root)=>{
    for(let p=e?.parentElement;p&&p!==root.parentElement;p=p.parentElement){
      if(p.scrollHeight>p.clientHeight+5&&/auto|scroll/.test(getComputedStyle(p).overflowY))return p;
    }
    return null;
  };
  const cancelSelection=async()=>{
    const b=main()&&labeled(main(),'Cancelar seleção');
    if(b){await click(b);await wait(()=>!labeled(main(),'Cancelar seleção'),'A seleção não foi cancelada.');}
  };
  const closeModal=async()=>{
    const m=modal();if(!m)return;
    await click(labeled(m,'Fechar'));await wait(()=>!modal(),'A janela de encaminhamento não fechou.');
  };
  const navigate=async()=>{
    if(modal())await closeModal();
    if(main())await cancelSelection();
    const channels=await wait(()=>labeled(document,'Canais'),'Aguarde o WhatsApp carregar: botão Canais indisponível.',30000);
    await click(channels);
    const channel=await wait(()=>all('button,[role="button"]').find(e=>visible(e)&&norm(e.getAttribute('aria-label'))===norm('Canal '+channelName)),'Canal Portal Felipe Tommy não encontrado na lista.');
    // O wrapper role=button não aciona necessariamente os handlers internos.
    // DOM real: newsletter-tab-newsletter-cell → cell-frame-container → title.
    const originOpen=()=>{
      const h=main()?.querySelector('header');
      return !!h&&norm(h.textContent).startsWith(norm(channelName));
    };
    for(let attempt=0;attempt<3;attempt++){
      const row=all('[role="button"],button').find(e=>visible(e)&&norm(e.getAttribute('aria-label'))===norm('Canal '+channelName));
      if(!row)throw Error('Canal de origem saiu da lista. Nenhum envio repetido.');
      const title=all('[data-testid="cell-frame-title"] [title]',row).find(e=>norm(e.getAttribute('title'))===norm(channelName));
      const target=title||row.querySelector('[data-testid="cell-frame-container"]')||row;
      target.scrollIntoView({block:'center'});await sleep(250);await checkpoint();
      if(attempt){
        const r=target.getBoundingClientRect(),opts={bubbles:true,cancelable:true,view:window,clientX:r.left+r.width/2,clientY:r.top+r.height/2,button:0};
        target.dispatchEvent(new PointerEvent('pointerdown',{...opts,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:1}));
        target.dispatchEvent(new MouseEvent('mousedown',{...opts,buttons:1}));
        target.dispatchEvent(new PointerEvent('pointerup',{...opts,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:0}));
        target.dispatchEvent(new MouseEvent('mouseup',{...opts,buttons:0}));
      }
      await click(target);
      for(let n=0;n<20&&!originOpen();n++)await sleep(200);
      if(originOpen())break;
      log('Retorno ao canal: tentativa '+(attempt+1)+' não confirmou abertura.');
    }
    // O nome do canal nao fica num <button>: em 19/09/2026 os <button> do header eram
    // ic-link, ic-switch-account e ic-more-vert. O titulo abre o texto do proprio header.
    await wait(()=>{
      const h=main()&&all('header',main())[0];
      if(!h)return false;
      if(norm(h.textContent).startsWith(norm(channelName)))return true;
      return all('button,[role="button"]',h).some(b=>norm(b.textContent).startsWith(norm(channelName)));
    },'O canal de origem não abriu.');
    await sleep(600);
  };
  const pinSource=async()=>{
    status('Identificando a última matéria e a enquete no canal…');
    // Chega ao fim antes de escolher a dupla. Mantém os IDs em todos os lotes.
    for(let i=0;i<8;i++){
      const ms=messages(),last=ms.at(-1);
      if(!last){await wait(()=>messages().length,'Nenhuma atualização carregada no canal.',30000);continue;}
      const sc=scrollParent(last,main());
      if(!sc||sc.scrollTop+sc.clientHeight>=sc.scrollHeight-4)break;
      sc.scrollTop=sc.scrollHeight;await sleep(600);
      if(i===7)throw Error('Não consegui confirmar o fim do canal.');
    }
    await wait(()=>{
      const ms=messages(),a=ms.at(-2),p=ms.at(-1);
      return a&&p&&a.textContent.trim()&&p.textContent.trim()&&(P.autoSource||a.querySelector('a[href]'))&&pollReady(p);
    },'Não reconheci uma enquete completa na última atualização do canal. Confira se a matéria e a enquete são as duas últimas publicações; se já aparecem, atualize o painel e gere um novo código.',30000);
    const ms=messages(),poll=ms.at(-1),article=ms.at(-2);
    const links=all('a[href]',article).map(a=>a.href).filter(h=>{try{return new URL(h).hostname==='felipetommy.com.br';}catch{return false;}});
    if(!isPoll(poll)||isPoll(article)||(!P.autoSource&&!links.length))throw Error('As duas últimas atualizações não são matéria + enquete. Confira o canal.');
    if(P.articleLinks?.length&&!P.articleLinks.some(h=>links.some(l=>l.replace(/\/$/,'')===h.replace(/\/$/,'')))){
      const title=norm(P.articleTitle);
      if(!title||!norm(article.textContent).includes(title))throw Error('A última matéria do canal não corresponde à carregada no painel.');
    }
    const current=[article.getAttribute('data-id'),poll.getAttribute('data-id')];
    if(source&&JSON.stringify(source.ids)!==JSON.stringify(current))throw Error('O par de atualizações mudou para esta matéria. Confira o conteúdo e o progresso antes de continuar.');
    source={ids:current,links,title:P.articleTitle||links[0]||article.textContent.trim().slice(0,160)};
    if(!dryRun&&!P.autoSource){ledger.source=source;save();}
    log('Origem fixada no canal: '+(links[0]||source.title)+' + enquete.');
  };
  const identifyProgress=()=>{
    // Identidade determinística do conteúdo, igual entre dispositivos.
    const ids=JSON.stringify(source.ids);
    sb.slug='canal-'+source.ids.map(id=>encodeURIComponent(id)).join('-');
    key='ft_forward_v5:'+sb.url+':'+sb.slug+(reviewOnly?':review':'');
    const stored=JSON.parse(localStorage.getItem(key)||'null');
    ledger=stored||{sent:{},pending:[],source};
    if(!ledger.sent||!Array.isArray(ledger.pending)||JSON.stringify(ledger.source?.ids)!==ids)throw Error('Registro de progresso incompatível com as atualizações do canal.');
    // Importa, sem apagar, os envios da v2.8.6 quando o par é EXATAMENTE igual.
    const prefix='ft_forward_v4:'+sb.url+':';
    for(let i=0;i<localStorage.length;i++){
      const oldKey=localStorage.key(i);
      if(!oldKey?.startsWith(prefix)||oldKey.endsWith(':review')!==reviewOnly)continue;
      let old;try{old=JSON.parse(localStorage.getItem(oldKey));}catch{throw Error('Registro antigo ilegível: confira o progresso antes de enviar.');}
      if(JSON.stringify(old?.source?.ids)!==ids)continue;
      if(!old.sent||!Array.isArray(old.pending))throw Error('Registro antigo de envio inválido.');
      Object.assign(ledger.sent,old.sent);
      for(const g of old.pending)if(!ledger.pending.some(p=>p.id===g.id))ledger.pending.push(g);
    }
    ledger.source=source;
    if(!dryRun)save();
  };
  const selectPair=async()=>{
    await cancelSelection();
    // Mesmo modo nativo de seleção da skill, aberto pelo menu sempre visível.
    const menu=await wait(()=>labeled(main()?.querySelector('header')||null,'Mais opções'),'Menu Mais opções do canal indisponível.');
    await click(menu);
    const option=await wait(()=>all('[role="menu"] [role="menuitem"],[role="menu"] span').find(e=>visible(e)&&norm(e.textContent)==='selecionar atualizacoes'),'Opção Selecionar atualizações não encontrada.');
    await click(option);
    await wait(()=>labeled(main(),'Cancelar seleção'),'O WhatsApp não entrou em modo de seleção.');
    for(const id of source.ids){
      const m=messages().find(e=>e.getAttribute('data-id')===id);
      if(!m)throw Error('Uma das atualizações de origem saiu da tela. Nenhuma outra será selecionada.');
      m.scrollIntoView({block:'nearest'});
      const cb=await wait(()=>selectedBox(messages().find(e=>e.getAttribute('data-id')===id)),'Caixa de seleção da atualização não encontrada.');
      if(!checked(cb))await click(cb);
      await wait(()=>checked(selectedBox(messages().find(e=>e.getAttribute('data-id')===id)||m)),'A atualização não foi selecionada.');
    }
    const chosen=messages().filter(m=>checked(selectedBox(m))).map(m=>m.getAttribute('data-id'));
    if(chosen.length!==2||chosen.some(id=>!source.ids.includes(id)))throw Error('Seleção diferente de matéria + enquete.');
    await wait(()=>all('span,div',main()).some(e=>norm(e.textContent)==='2 itens selecionados'),'O contador não confirmou 2 itens selecionados.');
    await click(labeled(main(),'Encaminhar mensagens'));
    await wait(modal,'A janela Encaminhar atualizações para não abriu.');
  };
  const typeSearch=async text=>{
    const m=modal();if(!m)throw Error('Janela de encaminhamento fechada.');
    const input=all('input[role="textbox"]',m).find(visible);
    if(!input)throw Error('Campo de busca do encaminhamento não encontrado.');
    await checkpoint();input.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,text);
    input.dispatchEvent(new Event('input',{bubbles:true}));
    await sleep(1300);
    const sc=scrollParent(rows(m)[0],m);if(sc){sc.scrollTop=0;await sleep(250);}
  };
  const selectionCount=()=>{
    const el=modal()?.querySelector('[aria-live="polite"][aria-label^="Você selecionou"]');
    return el?Number((el.getAttribute('aria-label').match(/\d+/)||[])[0]):0;
  };
  const limitedSearches=new Set();
  const prepareBatch=async(keyword,already=[],allowedIds=null)=>{
    await typeSearch(keyword);
    if(selectionCount()!==already.length)throw Error('Existem destinos selecionados fora deste lote. Feche a janela antes de retomar.');
    const marks=[...already],seen=new Set(already.map(g=>norm(g.nome))),observedNames=new Set();
    for(let page=0;page<20&&marks.length<5;page++){
      const m=modal();if(!m)throw Error('Janela fechou durante a escolha dos destinos.');
      const currentRows=rows(m);
      for(const candidate of currentRows){
        if(seen.size>=200)break;
        await checkpoint();
        const n=norm(rowName(candidate));
        if(searchText(rowName(candidate)).includes(searchText(keyword)))observedNames.add(rowName(candidate));
        if(!searchText(rowName(candidate)).includes(searchText(keyword)))continue; // Não consumir resultados da busca anterior.
        if(!n||seen.has(n))continue;seen.add(n);
        const row=rows(modal()||m).find(r=>norm(rowName(r))===n);
        const g=remaining.get(n);
        // Só nomes completos da lista autorizada. Nunca correspondência parcial.
        if(!g||(allowedIds&&!allowedIds.has(g.id))||marks.some(x=>x.id===g.id)||!enabled(row))continue;
        if(rows(m).filter(r=>norm(rowName(r))===n).length!==1)throw Error('Nome de grupo ambíguo: '+g.nome);
        if(checked(row))throw Error('Destino já marcado fora do controle: '+g.nome);
        await click(row);
        await wait(()=>rows(modal()||m).some(r=>norm(rowName(r))===n&&checked(r)),'Não confirmou a marcação de '+g.nome);
        marks.push(g);
        await wait(()=>selectionCount()===marks.length,'Contador de destinos divergente.');
        if(marks.length===5)break;
      }
      if(marks.length===5)break;
      if(![...remaining.values()].some(g=>searchText(g.nome).includes(searchText(keyword))&&!marks.some(x=>x.id===g.id)))break;
      const sc=scrollParent(rows(modal()||m).at(-1),m);
      if(seen.size>=200||(page===19&&sc&&sc.scrollTop+sc.clientHeight<sc.scrollHeight-3)){
        limitedSearches.add(keyword);
        log('"'+keyword+'": busca extensa; mantendo os marcados e tentando outras palavras. Destinos não localizados ficam pendentes.');
        break;
      }
      if(!sc||sc.scrollTop+sc.clientHeight>=sc.scrollHeight-3)break;
      const before=sc.scrollTop;sc.scrollTop+=Math.max(100,sc.clientHeight*0.8);
      await sleep(450);
      if(sc.scrollTop===before)break;
    }
    if(marks.length&&selectionCount()!==marks.length)throw Error('Número de destinos não corresponde ao lote.');
    if(marks.length===already.length){
      const expected=[...remaining.values()].filter(g=>searchText(g.nome).includes(searchText(keyword)));
      if(expected.length&&observedNames.size){
        log('Confira os nomes na aba Grupos. Cadastro: '+expected.slice(0,5).map(g=>g.nome).join(' | ')+'. WhatsApp: '+[...observedNames].slice(0,5).join(' | ')+'. Nenhum destino escolhido por semelhança.');
      }
    }
    return marks;
  };
  // Busca e identidade são coisas diferentes: pesquisa curta, nome completo
  // conferido no resultado. Não transforma um nome parecido em destino autorizado.
  const commonWords=new Set(['para','pelo','pela','pelos','pelas','grupo','grupos','todos','todas','somos']);
  const searchText=name=>norm(String(name||'').normalize('NFKD'));
  // Letras em quadrados não são convertidas pelo WhatsApp: pesquisar o token original.
  const searchWords=name=>[...new Set((searchText(name).match(/[a-z]+|[\u{1F170}-\u{1F189}]+/gu)||[]).filter(w=>Array.from(w).length>=4&&!commonWords.has(w)))];
  // Uma palavra principal por grupo antes das alternativas. Nunca "to", "br",
  // "vs", números ou fragmentos de emojis. "la vai" é uma expressão explícita.
  const groupSearchPlan=groups.map(g=>({id:g.id,nome:g.nome,palavras:searchWords(g.nome).slice(0,3)}));
  const preferred=keywords.map(norm).filter(k=>k==='la vai'||(/^[a-z]{4,}$/.test(k)&&!commonWords.has(k)));
  const searchJobs=[...new Set([...preferred,...groupSearchPlan.flatMap(g=>g.palavras.slice(0,1)),...groupSearchPlan.flatMap(g=>g.palavras.slice(1))])];
  const prepareKeywordBatch=async cursor=>{
    let marks=[];
    while(cursor.index<searchJobs.length&&marks.length<5){
      const keyword=searchJobs[cursor.index];
      // Após esgotar uma busca, completa o MESMO lote com a palavra seguinte.
      // Não busca palavras sem nenhum destino pendente ainda por marcar.
      const expected=[...remaining.values()].some(g=>!marks.some(m=>m.id===g.id)&&(keyword==='la vai'?norm(g.nome).includes(keyword):searchWords(g.nome).some(w=>w.startsWith(keyword))));
      if(!expected){cursor.index++;continue;}
      status((dryRun?'TESTE · ':'')+keyword+' · '+remaining.size+' pendentes · '+marks.length+'/5 marcados');
      const before=marks.length;
      marks=await prepareBatch(keyword,marks);
      if(marks.length===before)log('"'+keyword+'": nenhum pendente correspondente localizado; seguindo a busca.');
      // Se encheu, repete a mesma palavra no próximo ciclo para pegar os demais.
      if(marks.length<5)cursor.index++;
    }
    return marks;
  };
  // O WhatsApp bloqueia fetch ao Supabase por CSP. Apenas o painel acessa o banco.
  const protocol='ft-forward-bridge-v1',bridgeToken=crypto.randomUUID(),bridgeRequests=new Map();
  let bridgeWindow=null,bridgeReady=false,bridgeOrigin='',bridgeSeq=0;
  const onBridgeMessage=event=>{
    const m=event.data;
    if(event.origin!==bridgeOrigin||event.source!==bridgeWindow||m?.protocol!==protocol||m.token!==bridgeToken)return;
    if(m.kind==='ready'){bridgeReady=true;return;}
    if(m.kind==='result'){
      const req=bridgeRequests.get(m.id);if(!req)return;
      clearTimeout(req.timer);bridgeRequests.delete(m.id);
      m.ok?req.resolve(m.rows||[]):req.reject(Error(m.error||'A sincronização do painel falhou.'));
    }
  };
  window.addEventListener('message',onBridgeMessage);
  const openBridge=()=>{
    if(dryRun||reviewOnly)return;
    if(bridgeWindow&&!bridgeWindow.closed)return;
    if(!P.bridgeUrl)throw Error('Copie um código novo da versão atual do painel.');
    const url=new URL(P.bridgeUrl);
    if(url.protocol!=='https:')throw Error('Abra o painel publicado em HTTPS e copie o código novamente.');
    bridgeOrigin=url.origin;url.hash='token='+bridgeToken;bridgeReady=false;
    // Chamado diretamente em Iniciar, antes de qualquer await (gesto do usuário).
    bridgeWindow=window.open(url.href,'ft-forward-sync-'+bridgeToken,'popup,width=520,height=430');
    if(!bridgeWindow)throw Error('A janela de sincronização não abriu. Permita a janela do painel e clique Iniciar novamente. Nenhum envio iniciado.');
  };
  const bridgeRequest=async(kind,ids)=>{
    if(!bridgeWindow||bridgeWindow.closed)throw Error('A janela de sincronização foi fechada. Clique Iniciar para reabri-la; o progresso local foi preservado.');
    status('Sincronizando pelo painel…');
    for(let n=0;n<100&&!bridgeReady;n++){
      bridgeWindow.postMessage({protocol,token:bridgeToken,kind:'ping'},bridgeOrigin);await sleep(200);
    }
    if(!bridgeReady)throw Error('A janela do painel não respondeu. Confira se ela abriu e se a versão foi atualizada; nenhum reenvio automático.');
    return new Promise((resolve,reject)=>{
      const id=String(++bridgeSeq);
      const timer=setTimeout(()=>{bridgeRequests.delete(id);reject(Error('Sincronização sem resposta. Progresso local preservado; clique Iniciar para tentar novamente.'));},20000);
      bridgeRequests.set(id,{resolve,reject,timer});
      bridgeWindow.postMessage({protocol,token:bridgeToken,id,kind,project:sb.url,slug:sb.slug,ids},bridgeOrigin);
    });
  };
  const sync=async()=>{
    if(reviewOnly)return; // O teste privado nunca marca grupos de distribuição.
    const ids=Object.keys(ledger.sent).filter(id=>!synced.has(id));
    if(!ids.length)return;
    await bridgeRequest('sync',ids);
    ids.forEach(id=>synced.add(id));
  };
  const loadProgress=async()=>{
    if(dryRun)return;
    // Outra aba pode ter terminado enquanto este painel aguardava Iniciar.
    ledger=JSON.parse(localStorage.getItem(key));source=ledger.source;
    if(ledger.pending.length)throw Error('Há um lote com resultado incerto. Confira os grupos indicados no relatório antes de retomar.');
    if(reviewOnly){
      for(const [name,g] of remaining)if(ledger.sent[g.id])remaining.delete(name);
      progress();return;
    }
    const data=await bridgeRequest('load');
    for(const row of data)synced.add(row.grupo_id);
    for(const [name,g] of remaining)if(synced.has(g.id)||ledger.sent[g.id])remaining.delete(name);
    await sync();progress();
  };
  const sendBatch=async marks=>{
    if(marks.length<1||marks.length>5||selectionCount()!==marks.length)throw Error('Lote inválido; nada enviado.');
    const btn=labeled(modal(),'Enviar');
    if(!btn)throw Error('Botão Enviar do modal não encontrado.');
    if(dryRun){
      log('TESTE: '+marks.map(g=>g.nome).join(', ')+'; envio bloqueado.');
      await closeModal();await cancelSelection();
    }else{
      await checkpoint();
      // Grava antes do clique: uma interrupção nunca dispara de novo automaticamente.
      ledger.pending=marks.map(g=>({id:g.id,nome:g.nome}));save();
      await click(btn);
      // Após o clique, termina a apuração mesmo se Pausar/Parar for pressionado.
      const until=Date.now()+15000;let accepted=false;
      while(Date.now()<until){
        if(!modal()&&main()&&!labeled(main(),'Cancelar seleção')){accepted=true;break;}
        await rawSleep(200);
      }
      if(!accepted)throw Error('Não houve confirmação visual do envio. Lote preservado como incerto; não será repetido.');
      for(const g of marks)ledger.sent[g.id]={nome:g.nome,at:new Date().toISOString()};
      ledger.pending=[];save();
      for(const g of marks)remaining.delete(norm(g.nome));
      progress();
      log('WhatsApp aceitou '+marks.length+': '+marks.map(g=>g.nome).join(', '));
      await sync(); // Se falhar, para. O registro local impede reenvio.
    }
    // No teste também avança a fila em memória, sem gravar envios no ledger.
    for(const g of marks)remaining.delete(norm(g.nome));
    progress();
  };
  const execute=async()=>{
    if(P.autoSource){await navigate();await pinSource();identifyProgress();}
    await loadProgress();
    if(!remaining.size){await navigate();status('Concluído: grupos já registrados; retorno ao canal confirmado. Nenhum reenvio.');return;}
    if(!P.autoSource){await navigate();await pinSource();}
    let batches=0;
    const cursor={index:0};
      while(remaining.size&&cursor.index<searchJobs.length){
        await checkpoint();
        if(!modal())await selectPair();
        const marks=await prepareKeywordBatch(cursor);
        if(!marks.length)break;
        await sendBatch(marks);batches++;
        // O ciclo só termina ao VOLTAR: inclusive um teste de destino único
        // ou o último bloco da lista de 130. Registros de envio já estão salvos.
        status('Bloco '+batches+' · voltando a Canais → '+channelName+'…');
        await navigate();
        await wait(()=>source.ids.every(id=>messages().some(m=>m.getAttribute('data-id')===id&&m.textContent.trim())),
          'O bloco foi processado, mas a origem não reapareceu. Progresso preservado; nenhuma outra atualização será selecionada.',30000);
        log('Ciclo '+batches+' completo: retorno ao canal confirmado; '+remaining.size+' de '+groups.length+' pendentes.');
        // Teste percorre também o retorno ao canal, sem tocar no progresso real.
        if(dryRun&&batches>=2){status('Teste concluído: dois ciclos completos, nenhum envio.');return;}
        if(!remaining.size)break;
        await sleep(Math.max(4000,Number(P.delayMs)||4000)+Math.random()*Math.max(0,Number(P.jitterMs)||0));
      }
    if(modal())await closeModal();
    await cancelSelection();
    status(dryRun?'Teste concluído: '+batches+' lote(s) preparado(s), nenhum envio.':remaining.size?'Parcial: '+remaining.size+' grupo(s) não localizado(s). Veja o relatório.':'Concluído: todos os grupos selecionados foram encaminhados.');
    if(remaining.size)log('Não encontrados: '+[...remaining.values()].map(g=>g.nome).join(', '));
  };
  const run=async()=>{
    if(busy)return;
    busy=true;state='running';remaining=new Map(byName);synced=new Set();
    ui('[data-act="start"]').disabled=true;ui('[data-act="pause"]').disabled=false;ui('[data-act="stop"]').disabled=false;
    try{
      openBridge();
      if(!navigator.locks)throw Error('Este navegador não oferece trava para impedir duas rodadas simultâneas.');
      await navigator.locks.request(lockKey,{ifAvailable:true},async lock=>{
        if(!lock)throw Error('Esta matéria já está rodando em outra aba.');
        await execute();
      });
    }catch(e){status(e.message);log(e.message);}
    finally{
      state='idle';busy=false;
      ui('[data-act="start"]').disabled=false;ui('[data-act="pause"]').disabled=true;ui('[data-act="stop"]').disabled=true;ui('[data-act="pause"]').textContent='⏸ Pausar';
      if(closed){window.removeEventListener('message',onBridgeMessage);if(bridgeWindow&&!bridgeWindow.closed)bridgeWindow.close();box.remove();window.__ftAuto=false;}
    }
  };
  ui('[data-act="start"]').onclick=run;
  ui('[data-act="pause"]').onclick=()=>{state=state==='paused'?'running':'paused';ui('[data-act="pause"]').textContent=state==='paused'?'▶ Retomar':'⏸ Pausar';};
  ui('[data-act="stop"]').onclick=()=>{state='stopped';status('Parando; aguardando terminar a confirmação de eventual envio em andamento.');};
  ui('[data-act="close"]').onclick=()=>{closed=true;state='stopped';if(!busy){window.removeEventListener('message',onBridgeMessage);if(bridgeWindow&&!bridgeWindow.closed)bridgeWindow.close();box.remove();window.__ftAuto=false;}else status('Encerrando…');};
  ui('[data-act="report"]').onclick=()=>{
    const data={versao,materia:sb.slug,teste:dryRun,testeReal:!!P.testBatch,cicloPrivado:reviewOnly,origem:source,enviados:dryRun?[]:Object.keys(ledger.sent).map(id=>({id,...ledger.sent[id]})),incertos:ledger.pending,pendentes:[...remaining.values()],planoBuscas:groupSearchPlan,buscasLimitadas:[...limitedSearches]};
    const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download='encaminhamento-'+sb.slug.replace(/[^a-z0-9_-]/gi,'_')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
}
  ftWhatsAppRunner(P);
  return window.__ftAuto && document.getElementById('_ftForward') ? {ok:true} : {ok:false,error:'O robô não abriu. Confira o aviso no WhatsApp.'};
}

function ftExtensionCleanupLaunch(P) {
  if (location.origin !== 'https://web.whatsapp.com') return {ok:false,error:'Abra o WhatsApp Web.'};
  // Robô de limpeza. Incluído no painel e empacotado na extensão pelo gerador.
function ftWhatsAppCleanup(P){
  'use strict';
  if(location.hostname!=='web.whatsapp.com')throw Error('Abra o WhatsApp Web.');
  if(window.__ftAuto||document.getElementById('_ftForward')||document.getElementById('_ftCleanup'))throw Error('Feche o robô anterior pelo X.');
  const norm=s=>String(s||'').normalize('NFC').replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim();
  // Preserva emojis, acentos, números e maiúsculas: nomes parecidos não são iguais.
  const text=e=>!e?'':e.nodeType===3?e.textContent:e.tagName==='IMG'?(e.getAttribute('alt')||''):e.nodeType!==1||e.tagName.toLowerCase()==='svg'||e.getAttribute('aria-hidden')==='true'?'':[...e.childNodes].map(text).join('');
  if(P.mode!=='cleanup'||!Array.isArray(P.groups)||!P.groups.length||typeof P.keepStarred!=='boolean'||typeof P.dryRun!=='boolean'||!/^[-a-f0-9]{36}$/i.test(P.jobId))throw Error('Rodada de limpeza inválida.');
  const groups=P.groups, names=new Set(),ids=new Set();
  for(const g of groups){if(!g.id||!norm(g.nome)||names.has(norm(g.nome))||ids.has(g.id))throw Error('Corrija nomes vazios ou repetidos no cadastro.');names.add(norm(g.nome));ids.add(g.id);}
  const key='ft_cleanup_v1:'+P.jobId, signature=JSON.stringify({groups,keepStarred:P.keepStarred,dryRun:P.dryRun});
  let ledger;
  try{ledger=JSON.parse(localStorage.getItem(key)||'null')||{signature,results:{}};if(ledger.signature!==signature||!ledger.results||typeof ledger.results!=='object')throw Error();}
  catch{throw Error('O registro desta rodada está inválido. Confira o relatório antes de abrir outra rodada.');}
  let state='idle',busy=false,closed=false,committing=false;
  const save=()=>localStorage.setItem(key,JSON.stringify(ledger));
  const box=document.createElement('section');box.id='_ftCleanup';
  box.style.cssText='position:fixed;top:16px;right:16px;width:min(390px,94vw);max-height:90vh;overflow:auto;background:#111b21;color:#e9edef;border:2px solid #f4ad53;border-radius:12px;padding:16px;font:14px Segoe UI,sans-serif;z-index:2147483647;box-shadow:0 8px 30px #0008';
  box.innerHTML='<style>#_ftCleanup button{padding:9px 12px;margin:3px;border:0;border-radius:6px;background:#c6e5ff;color:#10202b;font:700 13px Segoe UI;cursor:pointer}#_ftCleanup button:disabled{opacity:.5;cursor:default}#_ftCleanup [data-start]{background:#ffbf75}#_ftCleanup [data-stop]{background:#ff929c}</style><b>Limpar conversas · v'+P.versao+'</b><button data-close aria-label="Fechar robô de limpeza">✕</button><p data-info></p><details><summary>Conferir grupos desta rodada</summary><ol data-groups style="max-height:150px;overflow:auto"></ol></details><p data-status role="status"></p><progress style="width:100%" value="0" max="100"></progress><div data-log style="max-height:170px;overflow:auto"></div><button data-start>Iniciar limpeza</button><button data-pause disabled>Pausar</button><button data-stop disabled>Parar</button><button data-report>Relatório</button><pre data-results hidden style="white-space:pre-wrap;max-height:240px;overflow:auto;font:12px Segoe UI"></pre>';
  document.body.appendChild(box);window.__ftAuto=true;
  const ui=s=>box.querySelector(s),status=t=>ui('[data-status]').textContent=t;
  ui('[data-info]').textContent=P.dryRun?'TESTE: abre a confirmação e cancela, sem apagar mensagens.':groups.length+' grupos. Apaga o histórico das conversas selecionadas. '+(P.keepStarred?'Mantém mensagens favoritas.':'Apaga também as mensagens favoritas.')+' Confira a lista e clique em Iniciar limpeza.';
  for(const g of groups){const li=document.createElement('li');li.textContent=g.nome;ui('[data-groups]').appendChild(li);}
  const log=t=>{const d=document.createElement('div');d.textContent=t;ui('[data-log]').appendChild(d);d.scrollIntoView({block:'nearest'});};
  const done=g=>ledger.results[g.id]?.status===(P.dryRun?'checked':'clean');
  const progress=()=>{const n=groups.filter(done).length;ui('progress').value=100*n/groups.length;return n;};
  status(progress()+' de '+groups.length+' confirmados. Pronto para iniciar.');
  if(P.dryRun)ui('[data-start]').textContent='Iniciar teste sem apagar';
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const check=()=>{if(state==='stopped'||closed)throw Error('Interrompido. Progresso preservado.');};
  const wait=async(fn,why,timeout=12000)=>{for(let elapsed=0;elapsed<timeout;elapsed+=150){if(!committing)check();const v=fn();if(v)return v;await sleep(150);}throw Error(why);};
  const all=(s,r=document)=>[...r.querySelectorAll(s)];
  const visible=e=>!!e?.isConnected&&e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden';
  const label=e=>norm(e.getAttribute('aria-label')||text(e));
  const exact=(root,name)=>{const list=all('button,[role="button"],[role="menuitem"]',root).filter(e=>visible(e)&&label(e)===name);if(list.length>1)throw Error('Controle duplicado: '+name);return list[0];};
  const click=e=>{check();if(!visible(e)||e.disabled||e.getAttribute('aria-disabled')==='true')throw Error('Controle indisponível.');if(/sair do grupo|denunciar|excluir grupo/i.test(label(e)))throw Error('Ação proibida para o robô de limpeza.');e.scrollIntoView({block:'center'});e.click();};
  // Alguns controles do WhatsApp só respondem à sequência de ponteiro.
  // Retentativas são exclusivas da navegação; a confirmação destrutiva nunca é repetida.
  const navigate=async(target,ready,why)=>{
    if(ready())return;
    for(let attempt=0;attempt<2;attempt++){
      check();const e=target();if(!visible(e))throw Error(why);
      if(attempt===0)click(e);
      else{
        e.scrollIntoView({block:'center'});e.focus();
        const r=e.getBoundingClientRect(),base={bubbles:true,cancelable:true,view:window,clientX:r.left+r.width/2,clientY:r.top+r.height/2,button:0};
        e.dispatchEvent(new PointerEvent('pointerdown',{...base,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:1}));
        e.dispatchEvent(new MouseEvent('mousedown',{...base,buttons:1}));
        e.dispatchEvent(new PointerEvent('pointerup',{...base,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:0}));
        e.dispatchEvent(new MouseEvent('mouseup',{...base,buttons:0}));e.click();
      }
      for(let elapsed=0;elapsed<(attempt?5000:1500);elapsed+=150){check();if(ready())return;await sleep(150);}
    }
    throw Error(why);
  };
  const drawer=()=>all('[role="complementary"][aria-label="Dados do grupo"]').find(visible);
  const headerName=()=>norm(text(document.querySelector('#main [data-testid="conversation-info-header-chat-title"]')));
  const assertGroup=g=>{if(headerName()!==norm(g.nome)||!document.querySelector('#main [data-testid="conversation-info-header-button"][aria-label="Dados do grupo"]'))throw Error('A conversa aberta não corresponde ao grupo selecionado: '+g.nome);};
  const assertDrawer=g=>{assertGroup(g);const d=drawer();if(!d||norm(text(d.querySelector('[data-testid^="group-info-drawer-subject-input-read-only"]')))!==norm(g.nome))throw Error('Os dados do grupo não correspondem ao cadastro.');return d;};
  const dialogTitle=d=>{const h=d.getAttribute('aria-labelledby');return h?h.split(/\s+/).map(id=>text(document.getElementById(id))).join(' '):text(d.querySelector('h1,h2,[role="heading"]'));};
  const clearDialog=()=>{const matches=all('[role="dialog"]').filter(d=>visible(d)&&norm(dialogTitle(d)).startsWith('Deseja limpar a conversa '));if(matches.length>1)throw Error('Mais de uma confirmação de limpeza aberta.');return matches[0];};
  const assertDialog=g=>{const d=clearDialog();if(!d||norm(dialogTitle(d))!==norm('Deseja limpar a conversa "'+g.nome+'"?'))throw Error('Nome diferente na confirmação. Nada foi apagado.');assertGroup(g);return d;};
  const cancelDialog=async()=>{const d=clearDialog();if(d){click(exact(d,'Cancelar'));await wait(()=>!clearDialog(),'Não consegui cancelar a confirmação.');}};
  const closeDrawer=async()=>{const d=drawer();if(d){click(exact(d,'Fechar'));await wait(()=>!drawer(),'Não consegui fechar os dados do grupo.');}};
  // Ao preencher, o WhatsApp troca aria-label por "". data-tab/role continuam.
  const searchInput=()=>{
    const candidates=all('#side input[role="textbox"][data-tab="3"],#side input[aria-label="Pesquisar ou começar uma nova conversa"],#side [contenteditable="true"][role="textbox"]').filter(visible);
    if(candidates.length>1)throw Error('Mais de um campo de busca de conversas.');return candidates[0];
  };
  const fill=(el,value)=>{check();el.focus();if(el.tagName==='INPUT'){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,value);el.dispatchEvent(new Event('input',{bubbles:true}));}else{document.execCommand('selectAll',false,null);document.execCommand('insertText',false,value);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));}};
  const findGroup=async g=>{
    await cancelDialog();await closeDrawer();
    const conversations=()=>all('button[aria-label="Conversas"]').find(visible);
    if(conversations())await navigate(conversations,()=>{
      const b=conversations();return b&&(b.getAttribute('aria-pressed')==='true'||b.getAttribute('data-navbar-item-selected')==='true')&&searchInput();
    },'Não consegui abrir a aba Conversas.');
    await wait(searchInput,'Busca de conversas indisponível. Abra a aba Conversas.');
    const filter=document.getElementById('all-filter');if(visible(filter)&&filter.getAttribute('aria-selected')!=='true')click(filter);
    // O filtro pode remontar o input. Buscar de novo antes de preencher.
    const input=await wait(searchInput,'O campo de busca mudou ao abrir Conversas.');
    // A busca só reduz resultados. O nome completo, com emojis, decide o alvo.
    const query=g.nome.normalize('NFKC').replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
    fill(input,query||g.nome);await sleep(1000);check();
    const pane=await wait(()=>document.querySelector('#pane-side'),'Lista de conversas indisponível.');
    pane.scrollTop=0;await sleep(300);
    const rowTitle=row=>row.querySelector('[data-testid="cell-frame-container"] [data-testid="cell-frame-title"] [title]');
    const chatTitles=()=>all('[role="row"]',pane).map(rowTitle).filter(Boolean);
    // Aguarda o resultado renderizado, não só um prazo fixo após digitar.
    await wait(()=>chatTitles().some(e=>norm(e.title)===norm(g.nome)),'Grupo não encontrado pelo nome completo: '+g.nome);
    const matches=new Map();let finished=false;
    for(let page=0;page<80;page++){
      check();
      for(const row of all('[role="row"]',pane)){
        const title=rowTitle(row);
        if(title&&norm(title.getAttribute('title'))===norm(g.nome)){
          const identity=row.getAttribute('data-testid')+'|'+row.style.transform+'|'+row.getAttribute('aria-rowindex');
          matches.set(identity,{top:pane.scrollTop});
        }
      }
      if(matches.size>1)throw Error('Dois resultados com o mesmo nome. Corrija o cadastro: '+g.nome);
      // Resultados de mensagens vêm depois das conversas e não são destinos.
      if(pane.querySelector('[data-testid^="chatlist-message-"]')){finished=true;break;}
      if(pane.scrollTop+pane.clientHeight>=pane.scrollHeight-4){finished=true;break;}
      const before=pane.scrollTop;pane.scrollTop+=Math.max(100,pane.clientHeight-80);await sleep(300);if(pane.scrollTop===before)break;
    }
    if(!finished)throw Error('Busca extensa demais para conferir duplicidades: '+g.nome);
    if(matches.size!==1)throw Error('Grupo não encontrado pelo nome completo: '+g.nome);
    pane.scrollTop=[...matches.values()][0].top;await sleep(300);
    const target=()=>{
      const targets=chatTitles().filter(e=>visible(e)&&norm(e.title)===norm(g.nome));
      if(targets.length!==1)throw Error('Resultado da busca mudou.');return targets[0];
    };
    await navigate(target,()=>headerName()===norm(g.nome),'O grupo não abriu: '+g.nome);assertGroup(g);
  };
  const openConfirmation=async g=>{
    assertGroup(g);
    click(exact(document.querySelector('#main header'),'Mais opções'));
    const menu=await wait(()=>all('[role="menu"]').find(m=>visible(m)&&exact(m,'Dados do grupo')),'Menu de dados do grupo indisponível.');
    click(exact(menu,'Dados do grupo'));
    await wait(drawer,'Dados do grupo não abriram.');const d=assertDrawer(g);
    const clear=await wait(()=>d.querySelector('[data-testid="li-clear-chat"][aria-label="Limpar conversa"]'),'Botão Limpar conversa não encontrado.');
    clear.scrollIntoView({block:'center'});await sleep(250);assertDrawer(g);click(clear);
    await wait(clearDialog,'Confirmação de limpeza não abriu.');const modal=assertDialog(g);
    const toggle=modal.querySelector('input[role="switch"][aria-label="Manter mensagens favoritas"],input[type="checkbox"][aria-label="Manter mensagens favoritas"]');
    if(!toggle)throw Error('Não consegui conferir a opção de mensagens favoritas.');
    const checked=()=>toggle.getAttribute('aria-checked')===null?toggle.checked:toggle.getAttribute('aria-checked')==='true';
    if(checked()!==P.keepStarred){click(toggle);await wait(()=>checked()===P.keepStarred,'A opção de favoritas não mudou.');}
    assertDialog(g);return modal;
  };
  // Só aceita notificações do aplicativo, nunca mensagens ou o log do robô.
  const noticeState=()=>{
    const notices=all('[role="alert"],[role="status"],[data-testid*="toast"]').filter(e=>!box.contains(e)&&!e.closest('#main,#pane-side,[data-testid="chat-info-drawer"]')&&visible(e));
    const noticeText=e=>e.nodeType===1&&e.matches('button,[role="button"]')?'':e.nodeType===3?e.textContent:e.nodeType===1?[...e.childNodes].map(noticeText).join(''):'';
    const has=(e,label)=>norm(noticeText(e))===label||all('span,div',e).some(n=>norm(text(n))===label);
    return {clean:notices.some(e=>has(e,'Conversa limpa')),clearing:notices.some(e=>has(e,'Limpando conversa'))};
  };
  const toast=()=>noticeState().clean;
  const watchCleanup=g=>{
    let completed=false,seenBusy=false,lastSignal=Date.now();
    const sample=()=>{
      const n=noticeState();
      if(n.clearing){seenBusy=true;lastSignal=Date.now();}
      if(n.clean&&headerName()===norm(g.nome))completed=true;
      return n;
    };
    // Armado ANTES do clique. A confirmação fica registrada mesmo após sumir.
    const observer=new MutationObserver(sample);
    observer.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['role','data-testid','class','style','hidden','aria-hidden']});
    return {
      close:()=>observer.disconnect(),
      wait:async()=>{
        const started=Date.now();let lastStatus='';
        for(;;){
          const n=sample();assertGroup(g);
          if(completed&&!n.clearing&&!clearDialog())return;
          // Sem limite enquanto o WhatsApp informa que ainda está limpando.
          // O limite só detecta ausência de qualquer sinal de andamento/conclusão.
          if(!n.clearing&&Date.now()-lastSignal>=120000)throw Error('A confirmação não apareceu e o WhatsApp não mostra limpeza em andamento. Resultado incerto: '+g.nome+'. Confira no WhatsApp e use Relatório para resolver a pendência.');
          const seconds=Math.floor((Date.now()-started)/1000);
          const message=(state==='stopped'?'Parada solicitada. ':state==='paused'?'Pausa solicitada. ':'')+(n.clearing?'WhatsApp limpando ':seenBusy?'Aguardando a confirmação de limpeza de ':'Aguardando o WhatsApp limpar ')+g.nome+' · '+seconds+'s. O próximo grupo só começa após Conversa limpa.';
          if(message!==lastStatus){status(message);lastStatus=message;}
          await sleep(150);
        }
      }
    };
  };
  const cleanOne=async g=>{
    await findGroup(g);await openConfirmation(g);
    if(P.dryRun){await cancelDialog();ledger.results[g.id]={status:'checked',at:new Date().toISOString()};save();log('Conferido sem apagar: '+g.nome);return;}
    await wait(()=>!toast()&&!noticeState().clearing,'Existe outra limpeza ou confirmação em andamento. Aguarde o WhatsApp concluir.');
    check();const d=assertDialog(g),button=exact(d,'Limpar conversa');
    // Grava ANTES do clique. Uma queda após o clique bloqueia repetição automática.
    ledger.results[g.id]={status:'uncertain',at:new Date().toISOString()};save();
    committing=true;ui('[data-close]').disabled=true;
    const watcher=watchCleanup(g);
    try{
      click(button);
      await watcher.wait();
      ledger.results[g.id]={status:'clean',at:new Date().toISOString()};save();log('Conversa limpa: '+g.nome);
    }finally{watcher.close();committing=false;ui('[data-close]').disabled=false;}
  };
  const report=()=>{
    ui('[data-results]').hidden=false;
    const labels={clean:'LIMPA',checked:'CONFERIDA SEM APAGAR',uncertain:'INCERTA',failed:'PENDENTE'};
    ui('[data-results]').textContent='Rodada '+P.jobId+'\n'+groups.map(g=>{const r=ledger.results[g.id];return (labels[r?.status]||'PENDENTE')+' | '+g.nome+(r?.error?' | '+r.error:'');}).join('\n');
    let pending=ui('[data-pending]');if(!pending){pending=document.createElement('div');pending.setAttribute('data-pending','');box.appendChild(pending);}pending.replaceChildren();
    for(const g of groups.filter(g=>ledger.results[g.id]?.status==='uncertain')){
      const b=document.createElement('button');b.textContent='Já conferi Conversa limpa: '+g.nome;b.disabled=busy;
      b.onclick=async()=>{
        if(busy||!confirm('Você viu "Conversa limpa" no WhatsApp para o grupo "'+g.nome+'"?\n\nIsso apenas confirma o registro da rodada. Não apaga mensagens e não inicia o próximo grupo.'))return;
        b.disabled=true;
        try{
          await navigator.locks.request('ft-whatsapp-cleanup',{ifAvailable:true},async lock=>{
            if(!lock)throw Error('Há uma limpeza em andamento em outra aba.');
            if(noticeState().clearing)throw Error('O WhatsApp ainda está limpando. Espere aparecer Conversa limpa.');
            const stored=JSON.parse(localStorage.getItem(key)||'null');
            if(!stored||stored.signature!==signature)throw Error('Não consegui conferir o registro desta rodada.');
            ledger=stored;if(ledger.results[g.id]?.status!=='uncertain')throw Error('O registro desse grupo já mudou.');
            ledger.results[g.id]={status:'clean',at:new Date().toISOString(),verification:'user-confirmed'};save();
            status('Pendência resolvida: '+g.nome+'. Clique em Iniciar limpeza para continuar.');progress();
            ui('[data-start]').disabled=groups.some(g=>ledger.results[g.id]?.status==='uncertain');
          });
        }catch(e){status(e.message);}finally{report();}
      };
      pending.appendChild(b);
    }
  };
  const run=async()=>{
    if(busy)return;busy=true;state='running';ui('[data-start]').disabled=true;ui('[data-pause]').disabled=false;ui('[data-stop]').disabled=false;
    try{
      if(!navigator.locks)throw Error('Atualize o Chrome para executar a limpeza com controle de rodada.');
      await navigator.locks.request('ft-whatsapp-cleanup',{ifAvailable:true},async lock=>{
        if(!lock)throw Error('Já há uma limpeza em outra aba.');
        const stored=JSON.parse(localStorage.getItem(key)||'null');if(stored){if(stored.signature!==signature)throw Error('Rodada divergente.');ledger=stored;}
        if(Object.values(ledger.results).some(r=>r.status==='uncertain'))throw Error('Existe uma limpeza incerta. Confira no WhatsApp; se já viu Conversa limpa para esse grupo, confirme em Relatório para continuar a mesma rodada.');
        save();
        for(const g of groups){
          if(done(g))continue;
          while(state==='paused'){status('Pausado. Clique em Continuar.');await sleep(150);}check();
          status('Limpando '+g.nome+' · '+progress()+'/'+groups.length);
          try{await cleanOne(g);}catch(e){if(ledger.results[g.id]?.status!=='uncertain'){ledger.results[g.id]={status:'failed',error:e.message};save();}throw e;}
          progress();await sleep(1000);
        }
        await closeDrawer();status((P.dryRun?'Teste concluído: ':'Limpeza concluída: ')+progress()+' de '+groups.length+' grupos.');state='done';
      });
    }catch(e){state='stopped';status(e.message);log('Parou: '+e.message);report();}
    finally{busy=false;ui('[data-start]').disabled=state==='done'||Object.values(ledger.results).some(r=>r.status==='uncertain');ui('[data-pause]').disabled=true;ui('[data-stop]').disabled=true;ui('[data-pause]').textContent='Pausar';progress();if(!ui('[data-results]').hidden)report();}
  };
  ui('[data-start]').onclick=run;
  ui('[data-pause]').onclick=()=>{state=state==='paused'?'running':'paused';ui('[data-pause]').textContent=state==='paused'?'Continuar':'Pausar';if(state==='paused')status('Pausa solicitada. Concluindo o grupo atual antes de pausar.');};
  ui('[data-stop]').onclick=()=>{state='stopped';status(committing?'Parando após verificar a confirmação do grupo atual…':'Parada solicitada.');};
  ui('[data-report]').onclick=report;
  ui('[data-close]').onclick=()=>{if(busy){state='stopped';status('Parando. Aguarde e clique em X novamente.');return;}closed=true;box.remove();window.__ftAuto=false;};
}

  try { ftWhatsAppCleanup(P); return {ok:!!document.getElementById('_ftCleanup')}; }
  catch(e) { return {ok:false,error:e.message}; }
}
